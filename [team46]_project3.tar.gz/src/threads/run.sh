make clean
make grade>result
vi result
