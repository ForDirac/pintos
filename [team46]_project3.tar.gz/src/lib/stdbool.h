#ifndef __LIB_STDBOOL_H
#define __LIB_STDBOOL_H

#define bool	_Bool
#define true	1
#define false	0
#define __bool_true_false_are_defined	1

#endif /* lib/stdbool.h */
